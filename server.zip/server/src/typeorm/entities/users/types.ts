export type Role = 'ADMINISTRATOR' | 'STANDARD';
export type Language = 'en-US' | 'sl-SI';
